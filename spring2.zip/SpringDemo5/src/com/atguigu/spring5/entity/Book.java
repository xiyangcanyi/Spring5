package com.atguigu.spring5.entity;

/**
 * @author zyp
 * @create 2023-02-19 12:17
 */
public class Book {
    private String id;
    private String name;
    private String staus;

    public Book(){}

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStaus() {
        return staus;
    }

    public void setStaus(String staus) {
        this.staus = staus;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", staus='" + staus + '\'' +
                '}';
    }
}
