package com.atguigu.spring5.test;

import com.atguigu.spring5.entity.Book;
import com.atguigu.spring5.service.BookService;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zyp
 * @create 2023-02-19 12:33
 */
public class TestBook {

    @Test
    public void testJdbcTemplate(){
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("bean1.xml");
        BookService bookService = context.getBean("bookService", BookService.class);
        Book book=new Book();
//        添加

//        book.setUserId("2");
//        book.setUsername("python");
//        book.setUstaus("yes");
//        bookService.addBook(book);


//        修改

//        book.setName("c++");
//        book.setStaus("0");
//        book.setId("1");
//        bookService.updateBook(book);
//        bookService.deleteBook("2");

//        int count = bookService.selectCount();
//        System.out.println(count);
//        Book book1 = bookService.selectObj("2");
//        System.out.println(book1);

//        List<Book> list = bookService.selectList();
//        for (Book b : list) {
//            System.out.println(b);
//        }
//      批量添加
//        ArrayList<Object[]> list = new ArrayList<>();
//        String[] book1={"3","python","a"};
//        String[] book2={"4","C#","b"};
//        String[] book3={"5","Golang","c"};
//        list.add(book1);
//        list.add(book2);
//        list.add(book3);

//        bookService.batchAdd(list);

//        ArrayList<Object[]> list = new ArrayList<>();
//        String[] book1={"python..","a11","3"};
//        String[] book2={"C#..","b22","4"};

//        list.add(book1);
//        list.add(book2);
//        list.add(book3);
//      实现批量修改
//        bookService.batchUpdate(list);

//        实现批量删除
        ArrayList<Object[]> list = new ArrayList<>();
        String[] book1={"3"};
        String[] book2={"4"};

        list.add(book1);
        list.add(book2);

//      实现批量修改
        bookService.batchDelete(list);

    }
}
