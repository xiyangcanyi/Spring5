package com.atguigu.spring5.dao;

import com.atguigu.spring5.entity.Book;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author zyp
 * @create 2023-02-19 12:03
 */
@Repository
public interface BookDao {
//    添加的方法
    void add(Book book);

//    修改
    void update(Book book);
//  删除
    void delete(String id);

//    查询表中记录
    int selectCount();

//    查询某一对象
    Book selectObjInfo(String id);
// 查询集合
    List<Book> selectListInfo();
//批量添加
    void batchAddBook(List<Object[]> batchArgs);
//    批量修改
    void batchUpdateBook(List<Object[]> batchArgs);

    void batchDeleteBook(List<Object[]> batchArgs);
}
