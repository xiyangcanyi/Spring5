package com.atguigu.spring5.service;

import com.atguigu.spring5.dao.UserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionalEventListener;
/**
 * @author zyp
 * @create 2023-02-19 15:35
 */
//@Transactional(readOnly = false,propagation = Propagation.REQUIRED,isolation = Isolation.REPEATABLE_READ)//(默认隔离级别：可重复读)
@Transactional
@Service //这个注解可以添加到类上面（为所有的方法添加事务），// 也可以添加到方法上面（只为某个方法添加事务）
public class UserService {

    @Autowired
    private UserDao userDao;

    public void accountMoney() {


//            第一步：开启事务
//  注意出现异常不解决才有事务不一致性问题
            //第二步：进行业务操作
            // lucy少100
            userDao.reduceMoney();
//        出现异常（模拟异常）
            int i=10/0;
//      marry多100
            userDao.addMoney();
//            第三步没有异常，提交事务

//            第四步出现异常，事务回滚




    }
}