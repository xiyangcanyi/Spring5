package com.atguigu.spring5.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author zyp
 * @create 2023-02-19 21:13
 */
public class UserLog {

    private static final Logger log= LoggerFactory.getLogger(UserLog.class);

    public static void main(String[] args) {
        log.info("hello logge4j");
        log.debug("hello logge4j");
    }
}
