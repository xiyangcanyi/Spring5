package com.atguigu.spring5.dao;

import org.springframework.stereotype.Repository;

/**
 * @author zyp
 * @create 2023-02-19 15:35
 */

public interface UserDao {

    public void addMoney();
    public void reduceMoney();

}
