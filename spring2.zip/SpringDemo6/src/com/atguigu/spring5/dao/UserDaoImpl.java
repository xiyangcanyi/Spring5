package com.atguigu.spring5.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Arrays;

/**
 * @author zyp
 * @create 2023-02-19 15:36
 */
@Repository
public class UserDaoImpl implements UserDao{

    @Autowired
    private JdbcTemplate jdbcTemplate;

//    账户增加钱
    @Override
    public void addMoney() {
        String sql="update t_account set money=money+? where username=?";
        jdbcTemplate.update(sql, 100, "Marry");
    }
//账户减少钱
    @Override
    public void reduceMoney() {
        String sql="update t_account set money=money-? where username=?";
         jdbcTemplate.update(sql, 100, "Lucy");


    }
}
